# smarthouse
Education project 'Smarthose' for OTUS cource
